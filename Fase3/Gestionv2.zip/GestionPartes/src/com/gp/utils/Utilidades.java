/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.utils;

import com.gp.modelo.ConexionDB;
import com.gp.vista.VPrincipal;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;

/**
 *
 * @author msimm
 */
public class Utilidades {

    public static boolean esEntero(String valor) {

        if (valor == null || valor.isEmpty()) {
            return false;
        }

        try {
            Integer.parseInt(valor);
        } catch (NumberFormatException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        return true;
    }

    public static boolean esDecimal(String valor) {

        if (valor == null || valor.isEmpty()) {
            return false;
        }

        try {
            Double.parseDouble((new Double(getDouble(valor))).toString());

            return true;
        } catch (NumberFormatException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public static Date esFecha(String valor) {

        Date fecha = null;

        if (valor == null || valor.isEmpty()) {
            return null;
        }

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");

        try {
            fecha = formatter.parse(valor);

        } catch (ParseException ex) {
            Logger.getLogger(Utilidades.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

        return fecha;
    }

    public static String formatearFecha(Date fecha) {

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");

        return formatter.format(fecha);

    }

    public static String formatearDecimal(String num) {

        DecimalFormat formatter = new DecimalFormat("####,###.##");

        return formatter.format(getDouble(num));

        //NumberFormat nf = NumberFormat.getCurrencyInstance();
        //return nf.format(getDouble(num));
    }

    public static double getDouble(String num) {

        try {
            DecimalFormat formatter = new DecimalFormat("###.##");

            Number numero = formatter.parse(num);
            return numero.doubleValue();
        } catch (ParseException ex) {
            Logger.getLogger(Utilidades.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }

    }

    public static String cifrarContraseña(String contraseña) {

        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
            md.update(contraseña.getBytes());
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(VPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        byte byteData[] = md.digest();

        //Convertir a formato hexadecimal
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }
        //System.out.println("Hex format : " + sb.toString());
        return sb.toString();
    }

    public static void validarSoloLetras(JTextField campo) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (Character.isDigit(c)) {
                    e.consume();
                    if (c != 8) { //Si no es BackSpace
                        Toolkit.getDefaultToolkit().beep();
                    }
                }
            }
        });
    }

    public static void validarSoloNumeros(JTextField campo) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                int k = (int) e.getKeyChar();
                if (!Character.isDigit(c) && k != 44) {
                    e.consume();
                    if (c != 8) { //Si no es BackSpace
                        Toolkit.getDefaultToolkit().beep();
                    }
                }
            }
        });
    }

    public static void limitarCaracteres(JTextField campo, int len) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                int longitud = campo.getText().length();
                if (longitud >= len) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    public static void limitarDecimales(JTextField campo, int len) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                String valor = campo.getText();
                int pos = valor.indexOf(44);
                if (pos > 0 && valor.length() == pos + len + 1) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    public static Date sumarHoras(Date hora1, Date hora2) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(hora1);
        DateFormat hourFormat = new SimpleDateFormat("HH:mm:ss");
        String hora = hourFormat.format(hora2);
        calendar.add(Calendar.HOUR, Integer.parseInt(hora.substring(0,2)));
        calendar.add(Calendar.MINUTE, Integer.parseInt(hora.substring(3,2)));
        calendar.add(Calendar.SECOND, Integer.parseInt(hora.substring(6,2)));
        
        return calendar.getTime();
    }
    
     public static Date restarHoras(Date hora1, Date hora2) {

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(hora1);
        DateFormat hourFormat = new SimpleDateFormat("HH:mm:ss");
        String hora = hourFormat.format(hora2);
        calendar.add(Calendar.HOUR, -1*Integer.parseInt(hora.substring(0,2)));
        calendar.add(Calendar.MINUTE, -1*Integer.parseInt(hora.substring(3,2)));
        calendar.add(Calendar.SECOND, -1*Integer.parseInt(hora.substring(6,2)));
        
        return calendar.getTime();
    }
}
