/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gp.modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author msimm
 */
public class ConexionDB {
    
    private static ConexionDB instance = null;
    
    String url = "jdbc:oracle:thin:@10.10.10.9:1521:db12102";
    String usuer = "practica";
    String pwd = "practica";    
  
    private Connection conexion;
   
    /**
     *
     * @return
     */
    public Connection getConexion() {
        return conexion;
    }

    private ConexionDB() {
    
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            this.conexion = DriverManager.getConnection("jdbc:oracle:thin:@10.10.10.9:1521:db12102","practica", "practica");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    public static ConexionDB getInstance() {
        
        if(instance == null){
            instance = new ConexionDB();
        }
        return instance;
        
    }
    
    public void cerrarConexion(){
        try {
            this.conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
            
 }


