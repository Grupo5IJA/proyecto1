/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.trabajadores;

import java.util.Date;

/**
 *
 * @author 7fprog01
 */
public class Trabajador {
    
    private String dni;
    private String nombre;
    private String ape1;
    private String ape2;
    private String calle;
    private int portal;
    private int piso;
    private String mano;
    private String telfperson;
    private String telfempres;
    private Double salario;
    private Date fechanac;
    private String usuario;
    private String contra;
    private int codcentro;
    private int codcategoria;

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApe1() {
        return ape1;
    }

    public void setApe1(String ape1) {
        this.ape1 = ape1;
    }

    public String getApe2() {
        return ape2;
    }

    public void setApe2(String ape2) {
        this.ape2 = ape2;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public int getPortal() {
        return portal;
    }

    public void setPortal(int portal) {
        this.portal = portal;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public String getMano() {
        return mano;
    }

    public void setMano(String mano) {
        this.mano = mano;
    }

    public String getTelfperson() {
        return telfperson;
    }

    public void setTelfperson(String telfperson) {
        this.telfperson = telfperson;
    }

    public String getTelfempres() {
        return telfempres;
    }

    public void setTelfempres(String telfempres) {
        this.telfempres = telfempres;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public Date getFechanac() {
        return fechanac;
    }

    public void setFechanac(Date fechanac) {
        this.fechanac = fechanac;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContra() {
        return contra;
    }

    public void setContra(String contra) {
        this.contra = contra;
    }
    
        public int getCodcentro() {
        return codcentro;
    }

    public void setCodcentro(int codcentro) {
        this.codcentro = codcentro;
    }

    public int getCodcategoria() {
        return codcategoria;
    }

    public void setCodcategoria(int codcategoria) {
        this.codcategoria = codcategoria;
    }

    @Override
    public String toString() {
        return getDni() + "-" + getNombre() + " " + getApe1() + " " + getApe2();
    }

    
}
