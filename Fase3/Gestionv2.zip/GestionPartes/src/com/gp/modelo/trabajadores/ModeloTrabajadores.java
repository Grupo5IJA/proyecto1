/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.trabajadores;

import com.gp.modelo.Modelo;
import com.gp.utils.Utilidades;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author msimm
 */
public class ModeloTrabajadores extends Modelo{

    private int categoria;

    public int getCategoria() {
        return categoria;
    }

    public int insertarTrabajador(String dni, String nombre, String ape1, String ape2, String calle, String mano, int portal, int piso, String telfperson,
            String telfempres, Double salario, Date fechanac, String usuario, String contra, int centro, int categ) {

        try {
            sql = "INSERT INTO TRABAJADOR "
                    + "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, dni);
            pstatement.setString(2, nombre);
            pstatement.setString(3, ape1);
            pstatement.setString(4, ape2);
            pstatement.setString(5, calle);
            pstatement.setInt(6, portal);
            pstatement.setInt(7, piso);
            pstatement.setString(8, mano);
            pstatement.setString(9, telfperson);
            pstatement.setString(10, telfempres);
            pstatement.setDouble(11, salario);
            pstatement.setDate(12, new java.sql.Date(fechanac.getTime()));
            pstatement.setString(13, usuario);
            pstatement.setString(14, contra);
            pstatement.setInt(15, centro);
            pstatement.setInt(16, categ);

            //execute insert SQL statement
            pstatement.executeUpdate();

            /*
         }catch (SQLIntegrityConstraintViolationException ex){
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
             */
        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloTrabajadores.class.getName());
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return 0;
    }

    public int borrarTrabajador(String dni) {

        try {
            sql = "DELETE FROM TRABAJADOR WHERE DNI_TRABAJADOR = ? ";

            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, dni);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloTrabajadores.class.getName());
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return 0;

    }

    public int modificarTrabajador(String dni, String nombre, String ape1, String ape2, String calle, String mano, int portal, int piso, String telfperson,
            String telfempres, Double salario, Date fechanac, String usuario, String contra, int centro, int categ) {

        try {
            sql = "UPDATE TRABAJADOR SET NOMBRE_TRABAJADOR=?, APELLIDO1_TRABAJADOR=?, APELLIDO2_TRABAJADOR=?, CALLE_TRABAJADOR=?, "
                    + "PORTAL_TRABAJADOR=?, PISO_TRABAJADOR=?, MANO_TRABAJADOR=?, TELEFONO_PERSONAL_TRABAJADOR=?, TELEFONO_EMPRESA_TRABAJADOR=?,"
                    + "SALARIO_TRABAJADOR=?, FECHA_NACIMIENTO_TRABAJADOR=?, USUARIO=?, CONTRASEÑA=?, CENTRO_TRABAJO_COD_CENTRO=?, CATEGORIA_CODIGO_CATEGORIA=? "
                    + "WHERE DNI_TRABAJADOR=?";
            
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, nombre);
            pstatement.setString(2, ape1);
            pstatement.setString(3, ape2);
            pstatement.setString(4, calle);
            pstatement.setInt(5, portal);
            pstatement.setInt(6, piso);
            pstatement.setString(7, mano);
            pstatement.setString(8, telfperson);
            pstatement.setString(9, telfempres);
            pstatement.setDouble(10, salario);
            pstatement.setDate(11,  new java.sql.Date(fechanac.getTime()));
            pstatement.setString(12, usuario);
            pstatement.setString(13, contra);
            pstatement.setInt(14, centro);
            pstatement.setInt(15, categ);
            pstatement.setString(16, dni);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloTrabajadores.class.getName());
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return 0;

    }

    public ArrayList<Trabajador> listaTrabajadores() {

        ArrayList<Trabajador> ltrabajadores = new ArrayList<>();

        try {

            cstatement = conexion.prepareCall("{call read_trabajadores.buscar_todos_trabajadores (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            cstatement.registerOutParameter(1, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(2, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(3, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(4, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(5, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(6, OracleTypes.INTEGER);
            cstatement.registerOutParameter(7, OracleTypes.INTEGER);
            cstatement.registerOutParameter(8, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(9, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(10, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(11, OracleTypes.INTEGER);
            cstatement.registerOutParameter(12, OracleTypes.DATE);
            cstatement.registerOutParameter(13, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(14, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(15, OracleTypes.INTEGER);
            cstatement.registerOutParameter(16, OracleTypes.INTEGER);
            cstatement.registerOutParameter(17, OracleTypes.CURSOR); //REF Cursor

            cstatement.execute();

            rs = ((OracleCallableStatement) cstatement).getCursor(17);

            while (rs.next()) {

                Trabajador trabajador = new Trabajador();

                trabajador.setDni(rs.getString(1));
                trabajador.setNombre(rs.getString(2));
                trabajador.setApe1(rs.getString(3));
                trabajador.setApe2(rs.getString(4));
                trabajador.setCalle(rs.getString(5));
                trabajador.setPortal(rs.getInt(6));
                trabajador.setPiso(rs.getInt(7));
                trabajador.setMano(rs.getString(8));
                trabajador.setTelfperson(rs.getString(9));
                trabajador.setTelfempres(rs.getString(10));
                trabajador.setSalario(rs.getDouble(11));
                trabajador.setFechanac(rs.getDate(12));
                trabajador.setUsuario(rs.getString(13));
                trabajador.setContra(rs.getString(14));
                trabajador.setCodcentro(rs.getInt(15));
                trabajador.setCodcategoria(rs.getInt(16));

                ltrabajadores.add(trabajador);
            }
            
        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloTrabajadores.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return ltrabajadores;
    }

    public Trabajador datosTrabajador(String dni) {

        Trabajador trabajador = null;

        try {

            cstatement = conexion.prepareCall("{call read_trabajadores.buscar_trabajador (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            cstatement.setString(1, dni);
            cstatement.registerOutParameter(2, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(3, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(4, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(5, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(6, OracleTypes.INTEGER);
            cstatement.registerOutParameter(7, OracleTypes.INTEGER);
            cstatement.registerOutParameter(8, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(9, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(10, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(11, OracleTypes.INTEGER);
            cstatement.registerOutParameter(12, OracleTypes.DATE);
            cstatement.registerOutParameter(13, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(14, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(15, OracleTypes.INTEGER);
            cstatement.registerOutParameter(16, OracleTypes.INTEGER);

            cstatement.execute();

            trabajador = new Trabajador();

            trabajador.setDni(dni);
            trabajador.setNombre(cstatement.getString(2));
            trabajador.setApe1(cstatement.getString(3));
            trabajador.setApe2(cstatement.getString(4));
            trabajador.setCalle(cstatement.getString(5));
            trabajador.setPortal(cstatement.getInt(6));
            trabajador.setPiso(cstatement.getInt(7));
            trabajador.setMano(cstatement.getString(8));
            trabajador.setTelfperson(cstatement.getString(9));
            trabajador.setTelfempres(cstatement.getString(10));
            trabajador.setSalario(cstatement.getDouble(11));
            trabajador.setFechanac(cstatement.getDate(12));
            trabajador.setUsuario(cstatement.getString(13));
            trabajador.setContra(cstatement.getString(14));
            trabajador.setCodcentro(cstatement.getInt(15));
            trabajador.setCodcategoria(cstatement.getInt(16));

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloTrabajadores.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return trabajador;
    }
    
    public String dniTrabajador(String codusu) {

        if ("admin".equals(codusu)) {
            return null;
        }
        
        String dni = null;

        try {

            cstatement = conexion.prepareCall("{call read_trabajadores.buscar_dni_trabajador (?, ?)}");
            cstatement.setString(1, codusu);
            cstatement.registerOutParameter(2, OracleTypes.VARCHAR);

            cstatement.execute();

            dni = cstatement.getString(2);

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloTrabajadores.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return dni;
    }
    
    public int validarLogin(String usuario, String contraseña) {

        categoria = -1;

        if ("admin".equals(usuario) && Utilidades.cifrarContraseña("admin").equals(contraseña)) {
            return 2;
        }

        try {

            cstatement = conexion.prepareCall("{call read_trabajadores.login (?, ?, ?)}");
            cstatement.setString(1, usuario);
            cstatement.setString(2, contraseña);
            cstatement.registerOutParameter(3, OracleTypes.INTEGER);

            cstatement.execute();

            categoria = cstatement.getInt(3);

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloTrabajadores.class.getName());
        } finally {
            limpiarDatos(ModeloTrabajadores.class.getName());
        }

        return categoria;
    }

}
