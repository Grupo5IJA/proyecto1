/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.partes;

import com.gp.modelo.Modelo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author msimm
 */
public class ModeloPartes extends Modelo {

    public int insertarParte(Date fecha, String dni) {

        try {
            sql = "INSERT INTO PARTE (CODIGO_PARTE, FECHA_PARTE, ESTADO_PARTE, TRABAJADOR_DNI_TRABAJADOR) "
                    + "VALUES (SEQ_PARTE.nextval, ?, ?, ? )";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setDate(1, new java.sql.Date(fecha.getTime()));
            pstatement.setString(2, "A");
            pstatement.setString(3, dni);

            //execute insert SQL statement
            pstatement.executeUpdate();

            /*
         }catch (SQLIntegrityConstraintViolationException ex){
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
             */
        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloPartes.class.getName());
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return 0;
    }

    public int insertarParte2(Date fecha, int kminicio, int kmfin, int totalhoras, double gastosgasolina, double gastosautopistas, double gastosdietas, double gastos, String incidencias,
            String estado, String exceso, String dni, String matricula) {

        try {
            sql = "INSERT INTO PARTE "
                    + "VALUES (seq_parte, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setDate(1, new java.sql.Date(fecha.getTime()));
            pstatement.setInt(2, kminicio);
            pstatement.setInt(3, kmfin);
            pstatement.setInt(4, totalhoras);
            pstatement.setDouble(5, gastosgasolina);
            pstatement.setDouble(6, gastosautopistas);
            pstatement.setDouble(7, gastosdietas);
            pstatement.setDouble(8, gastos);
            pstatement.setString(9, incidencias);
            pstatement.setString(10, estado);
            pstatement.setString(11, exceso);
            pstatement.setString(12, dni);
            pstatement.setString(13, matricula);

            //execute insert SQL statement
            pstatement.executeUpdate();

            /*
         }catch (SQLIntegrityConstraintViolationException ex){
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
             */
        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloPartes.class.getName());
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return 0;
    }

    public int borrarParte(int codigo) {

        try {
            sql = "DELETE FROM PARTE WHERE CODIGO_PARTE = ? ";

            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloPartes.class.getName());
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return 0;

    }

    public int modificarParte(int codigo, Date fecha, int kminicio, int kmfin, Date totalhoras, double gastosgasolina, double gastosautopistas, double gastosdietas, double gastos, String incidencias,
            String estado, String dni, String matricula) {

        try {
            sql = "UPDATE PARTE SET FECHA_PARTE=?, KM_INICIO_PARTE=?, KM_FIN_PARTE=?, "
                    + "TOTAL_HORAS_PARTE=?, GASTOS_GASOLINA_PARTE=?, GASTOS_AUTOPISTAS_PARTE=?, GASTOS_DIETAS_PARTE=?, GASTOS_PARTE=?, "
                    + "INCIDENCIAS_PARTE=?, ESTADO_PARTE=?, TRABAJADOR_DNI_TRABAJADOR=?, VEHICULO_MATRICULA_VEHICULO=? "
                    + "WHERE CODIGO_PARTE=?";

            pstatement = conexion.prepareStatement(sql);
            
            pstatement.setDate(1, new java.sql.Date(fecha.getTime()));
            pstatement.setInt(2, kminicio);
            pstatement.setInt(3, kmfin);
            pstatement.setDate(4, new java.sql.Date(totalhoras.getTime()));
            pstatement.setDouble(5, gastosgasolina);
            pstatement.setDouble(6, gastosautopistas);
            pstatement.setDouble(7, gastosdietas);
            pstatement.setDouble(8, gastos);
            pstatement.setString(9, incidencias);
            pstatement.setString(10, estado);
            pstatement.setString(11, dni);
            pstatement.setString(12, matricula);
             pstatement.setInt(13, codigo);
             
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloPartes.class.getName());
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return 0;

    }

    public ArrayList<Parte> listaPartes(String dni, Date fecdesde, Date fechasta) {

        ArrayList<Parte> lpartes = new ArrayList<>();

        try {

            sql = "SELECT CODIGO_PARTE, FECHA_PARTE, KM_INICIO_PARTE, KM_FIN_PARTE, TOTAL_HORAS_PARTE, GASTOS_GASOLINA_PARTE, GASTOS_AUTOPISTAS_PARTE, "
                    + "GASTOS_DIETAS_PARTE, GASTOS_PARTE, INCIDENCIAS_PARTE, ESTADO_PARTE, EXCESO_HORAS, TRABAJADOR_DNI_TRABAJADOR, VEHICULO_MATRICULA_VEHICULO "
                    + "FROM PARTE ";
            if (dni != null) {
                sql += "WHERE TRABAJADOR_DNI_TRABAJADOR = ? AND FECHA_PARTE > ? AND FECHA_PARTE < ?";
            }

            pstatement = conexion.prepareStatement(sql);

            if (dni != null) {
                pstatement.setString(1, dni);
                pstatement.setDate(2, new java.sql.Date(fecdesde.getTime()));
                pstatement.setDate(3, new java.sql.Date(fechasta.getTime()));
            }

            rs = pstatement.executeQuery();

            while (rs.next()) {

                Parte parte = new Parte();

                parte.setCodigo(rs.getInt(1));
                parte.setFecha_parte(rs.getDate(2));
                parte.setKm_inicio(rs.getInt(3));
                parte.setKm_fin(rs.getInt(4));
                parte.setTotal_horas(rs.getInt(5));
                parte.setGastos_gasolina(rs.getDouble(6));
                parte.setGastos_autopista(rs.getDouble(7));
                parte.setGastos_dietas(rs.getDouble(8));
                parte.setGastos(rs.getDouble(9));
                parte.setIncidencias(rs.getString(10));
                parte.setEstado(rs.getString(11).toCharArray()[0]);
                parte.setExceso(rs.getDate(12));
                parte.setTrabajador_dni(rs.getString(13));
                parte.setVehiculo_matricula(rs.getString(14));

                lpartes.add(parte);
            }

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloPartes.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return lpartes;
    }

    public Parte datosParte(int codigo) {

        Parte parte = null;

        try {
            sql = "SELECT CODIGO_PARTE, FECHA_PARTE, KM_INICIO_PARTE, KM_FIN_PARTE, TOTAL_HORAS_PARTE, GASTOS_GASOLINA_PARTE, GASTOS_AUTOPISTAS_PARTE, GASTOS_DIETAS_PARTE, GASTOS_PARTE, "
                    + "INCIDENCIAS_PARTE, ESTADO_PARTE, EXCESO_HORAS, TRABAJADOR_DNI_TRABAJADOR, VEHICULO_MATRICULA_VEHICULO "
                    + "FROM PARTE "
                    + "WHERE CODIGO_PARTE = ?";

            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);

            rs = pstatement.executeQuery();

            rs.next();

            parte = new Parte();

            parte.setCodigo(codigo);

            parte.setFecha_parte(rs.getDate(2));
            parte.setKm_inicio(rs.getInt(3));
            parte.setKm_fin(rs.getInt(4));
            parte.setTotal_horas(rs.getInt(5));
            parte.setGastos_gasolina(rs.getDouble(6));
            parte.setGastos_autopista(rs.getDouble(7));
            parte.setGastos_dietas(rs.getDouble(8));
            parte.setGastos(rs.getDouble(9));
            parte.setIncidencias(rs.getString(10));
            parte.setEstado(rs.getString(11).toCharArray()[0]);
            parte.setExceso(rs.getDate(12));
            parte.setTrabajador_dni(rs.getString(13));
            parte.setVehiculo_matricula(rs.getString(14));

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloPartes.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return parte;
    }

    public Parte datosParteAbierto(String dni) {

        Parte parte = null;

        try {
            sql = "SELECT CODIGO_PARTE, FECHA_PARTE, KM_INICIO_PARTE, KM_FIN_PARTE, TOTAL_HORAS_PARTE, GASTOS_GASOLINA_PARTE, GASTOS_AUTOPISTAS_PARTE, GASTOS_DIETAS_PARTE, "
                    + "GASTOS_PARTE, INCIDENCIAS_PARTE, ESTADO_PARTE, EXCESO_HORAS, TRABAJADOR_DNI_TRABAJADOR, VEHICULO_MATRICULA_VEHICULO "
                    + "FROM PARTE "
                    + "WHERE TRABAJADOR_DNI_TRABAJADOR = ? AND ESTADO_PARTE='A'";

            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, dni);

            rs = pstatement.executeQuery();

            if (rs.next()) {

                parte = new Parte();

                parte.setCodigo(rs.getInt(1));
                parte.setFecha_parte(rs.getDate(2));
                parte.setKm_inicio(rs.getInt(3));
                parte.setKm_fin(rs.getInt(4));
                parte.setTotal_horas(rs.getInt(5));
                parte.setGastos_gasolina(rs.getDouble(6));
                parte.setGastos_autopista(rs.getDouble(7));
                parte.setGastos_dietas(rs.getDouble(8));
                parte.setGastos(rs.getDouble(9));
                parte.setIncidencias(rs.getString(10));
                parte.setEstado(rs.getString(11).toCharArray()[0]);
                parte.setExceso(rs.getDate(12));
                parte.setTrabajador_dni(rs.getString(13));
                parte.setVehiculo_matricula(rs.getString(14));
            }

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloPartes.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloPartes.class.getName());
        }

        return parte;
    }

}
