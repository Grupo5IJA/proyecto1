/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.partes;


import com.gp.modelo.ConexionDB;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author msimm
 */
public class PartesTM {
/**
 *
 * @author msimm
 */
    Connection conexion;
    DefaultTableModel modelo;
    ModeloPartes mp;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public PartesTM(ModeloPartes mp) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.mp = mp;

        addColumnas();

    }

    private void addColumnas() {

        
        modelo.addColumn("codigo ");
        modelo.addColumn("trabajador");
        modelo.addColumn("fecha_parte ");
        modelo.addColumn("km_inicio");
        modelo.addColumn("km_fin ");
        modelo.addColumn("total_horas ");
        modelo.addColumn("gastos_gasolina ");
        modelo.addColumn("gastos_autopistas ");
        modelo.addColumn("gastos_dietas ");
        modelo.addColumn("gastos");
        modelo.addColumn("incidencias");
        modelo.addColumn("estado");
        modelo.addColumn("exceso");

    }

    public void rellenarTabla(String dni, Date fecdesde, Date fechasta) {

        ArrayList<Parte> lpaPartes = mp.listaPartes(dni, fecdesde, fechasta);

        for (Parte parte : lpaPartes) {

            Object[] fila = new Object[13];

            fila[0] = parte.getCodigo();
            fila[1] = parte.getTrabajador_dni();
            fila[2] = parte.getFecha_parte();
            fila[3] = parte.getKm_inicio();
            fila[4] = parte.getKm_fin();
            fila[5] = parte.getTotal_horas();
            fila[6] = parte.getGastos_gasolina();
            fila[7] = parte.getGastos_autopista();
            fila[8] = parte.getGastos_dietas();
            fila[9] = parte.getGastos();
            fila[10] = parte.getIncidencias();
            fila[11] = parte.getEstado();
            fila[12] = parte.getExceso();

            modelo.addRow(fila);
        }
    }

    /**
     * Métode per vaciar la un Jtable con modelo
     *
     */
    public void vaciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }



    
}
