/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.centros;

import com.gp.modelo.ConexionDB;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author msimm
 */
public class CentrosTM {

    Connection conexion;
    DefaultTableModel modelo;
    ModeloCentros mc;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public CentrosTM(ModeloCentros mc) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.mc = mc;

        addColumnas();

    }

    private void addColumnas() {

        modelo.addColumn("Código");
        modelo.addColumn("Nombre");
        modelo.addColumn("Calle");
        modelo.addColumn("Número");
        modelo.addColumn("C.Postal");
        modelo.addColumn("Ciudad");
        modelo.addColumn("Provincia");
        modelo.addColumn("Teléfono");

    }

    public void rellenarTabla() {

        ArrayList<Centro> lcentros = mc.listaCentros();

        for (Centro centro : lcentros) {

            Object[] fila = new Object[8];

            fila[0] = centro.getCodigo();
            fila[1] = centro.getNombre();
            fila[2] = centro.getCalle();
            fila[3] = centro.getNumero();
            fila[4] = centro.getCodigo_postal();
            fila[5] = centro.getCiudad();
            fila[6] = centro.getProvincia();
            fila[7] = centro.getTelefono();

            modelo.addRow(fila);
        }
    }

    /**
     * Métode per vaciar la un Jtable con modelo
     *
     */
    public void vaciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }

}
