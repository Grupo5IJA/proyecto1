/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.viajes;

import java.util.Date;

/**
 *
 * @author msimm
 */
public class Viaje {
    
    private int codigo;
    private Date horaini;
    private Date horafin;
    private String codalbaran;
    private int codparte;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Date getHoraini() {
        return horaini;
    }

    public void setHoraini(Date horaini) {
        this.horaini = horaini;
    }

    public Date getHorafin() {
        return horafin;
    }

    public void setHorafin(Date horafin) {
        this.horafin = horafin;
    }

    public String getCodalbaran() {
        return codalbaran;
    }

    public void setCodalbaran(String codalbaran) {
        this.codalbaran = codalbaran;
    }

    public int getCodparte() {
        return codparte;
    }

    public void setCodparte(int codparte) {
        this.codparte = codparte;
    }
    

    
}
