/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.viajes;

import com.gp.modelo.ConexionDB;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author msimm
 */
public class ViajesTM {

    Connection conexion;
    DefaultTableModel modelo;
    ModeloViajes mv;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public ViajesTM(ModeloViajes mv) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.mv = mv;

        addColumnas();

    }

    private void addColumnas() {

        modelo.addColumn("Código");
        modelo.addColumn("Hora inicio");
        modelo.addColumn("Hora fin");
        modelo.addColumn("Albarán");

    }

    public void rellenarTabla() {

        ArrayList<Viaje> lviajes = mv.listaViajes();

        for (Viaje viaje : lviajes) {
            Object[] fila = new Object[4];
            fila[0] = viaje.getCodigo();
            fila[1] = viaje.getHoraini();
            fila[2] = viaje.getHorafin();
            fila[3] = viaje.getCodalbaran();

            modelo.addRow(fila);
        }

    }

    /**
     * Métode per vaciar la un Jtable con modelo
     *
     */
    public void vaciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }

}
