/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package como.gp.modelo.categorias;

import com.gp.modelo.Modelo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author msimm
 */
public class ModeloCategorias extends Modelo{

    public ArrayList<Categoria> listaCategorias(){
    
        ResultSet rs = null;
        ArrayList<Categoria> lcategorias = new ArrayList<>();

        try {
            sql = "SELECT CODIGO_CATEGORIA, NOMBRE_CATEGORIA FROM CATEGORIA";
            
            pstatement = conexion.prepareStatement(sql);
            
            rs = pstatement.executeQuery();
            
            while (rs.next()) {
                Categoria categoria = new Categoria(rs.getInt("CODIGO_CATEGORIA"), rs.getString("NOMBRE_CATEGORIA"));
                lcategorias.add(categoria);
            }
        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloCategorias.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloCategorias.class.getName());
        }

        return lcategorias;
         
    }
    
}
