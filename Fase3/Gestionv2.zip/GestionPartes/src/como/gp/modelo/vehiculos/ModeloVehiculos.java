/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package como.gp.modelo.vehiculos;

import com.gp.modelo.Modelo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author msimm
 */
public class ModeloVehiculos extends Modelo {

    public int insertarVehiculos(String matricula, String marca, String modelo) {

        try {

            sql = "INSERT INTO VEHICULO "
                    + "VALUES ( ?, ?, ?)";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, matricula);
            pstatement.setString(2, marca);
            pstatement.setString(3, modelo);

            // execute insert SQL stetement
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloVehiculos.class.getName());
        } finally {
            limpiarDatos(ModeloVehiculos.class.getName());
        }

        return 0;
    }

    public int borrarVehiculo(String matricula) {

        try {

            sql = "DELETE FROM VEHICULO WHERE MATRICULA_VEHICULO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, matricula);
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloVehiculos.class.getName());
        } finally {
            limpiarDatos(ModeloVehiculos.class.getName());
        }

        return 0;
    }

    public int modificarVehiculo(String matricula, String marca, String modelo) {

        try {

            sql = "UPDATE VEHICULO SET MARCA_VEHICULO= ?, MODELO_VEHICULO= ? "
                    + "WHERE MATRICULA_VEHICULO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, marca);
            pstatement.setString(2, modelo);
            pstatement.setString(3, matricula);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloVehiculos.class.getName());
        } finally {
            limpiarDatos(ModeloVehiculos.class.getName());
        }

        return 0;

    }

    public ArrayList<Vehiculo> listaVehiculos() {

        ArrayList<Vehiculo> lvehiculos = new ArrayList<>();

        try {

            sql = "SELECT MATRICULA_VEHICULO, MARCA_VEHICULO, MODELO_VEHICULO FROM VEHICULO";
            pstatement = conexion.prepareStatement(sql);

            rs = pstatement.executeQuery();

            while (rs.next()) {

                Vehiculo vehiculo = new Vehiculo();

                vehiculo.setMatricula(rs.getString("MATRICULA_VEHICULO"));
                vehiculo.setMarca(rs.getString("MARCA_VEHICULO"));
                vehiculo.setModelo(rs.getString("MODELO_VEHICULO"));

                lvehiculos.add(vehiculo);
            }
        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloVehiculos.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloVehiculos.class.getName());
        }

        return lvehiculos;
    }

    public Vehiculo datosVehiculo(String matricula) {

        Vehiculo vehiculo = null;

        try {

            sql = "SELECT MARCA_VEHICULO, MODELO_VEHICULO FROM VEHICULO "
                    + "WHERE MATRICULA_VEHICULO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, matricula);

            rs = pstatement.executeQuery();

            rs.next();

            vehiculo = new Vehiculo();

            vehiculo.setMatricula(matricula);

            vehiculo.setMarca(rs.getString("MARCA_VEHICULO"));
            vehiculo.setModelo(rs.getString("MODELO_VEHICULO"));

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloVehiculos.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloVehiculos.class.getName());
        }


        return vehiculo;
    }

}
