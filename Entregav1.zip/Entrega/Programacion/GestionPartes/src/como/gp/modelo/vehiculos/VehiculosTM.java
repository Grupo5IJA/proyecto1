/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package como.gp.modelo.vehiculos;

import com.gp.modelo.ConexionDB;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author msimm
 */
public class VehiculosTM {

    Connection conexion;
    DefaultTableModel modelo;
    ModeloVehiculos mv;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public VehiculosTM(ModeloVehiculos mv) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.mv = mv;

        addColumnas();

    }

    private void addColumnas() {

        modelo.addColumn("Matrícula");
        modelo.addColumn("Marca");
        modelo.addColumn("Modelo");

    }

    public void rellenarTabla() {

        ArrayList<Vehiculo> lvehiculos = mv.listaVehiculos();

        for (Vehiculo vehiculo : lvehiculos) {
            Object[] fila = new Object[3];
            fila[0] = vehiculo.getMatricula();
            fila[1] = vehiculo.getMarca();
            fila[2] = vehiculo.getModelo();

            modelo.addRow(fila);
        }

    }

    /**
     * Métode per vaciar la un Jtable con modelo
     *
     */
    public void vaciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }

}
