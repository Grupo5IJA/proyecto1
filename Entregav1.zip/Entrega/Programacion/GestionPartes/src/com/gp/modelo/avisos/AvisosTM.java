/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.avisos;

import com.gp.modelo.ConexionDB;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author msimm
 */
public class AvisosTM {
    
    Connection conexion;
    DefaultTableModel modelo;
    ModeloAvisos ma;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public AvisosTM(ModeloAvisos ma) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.ma = ma;

        addColumnas();

    }

    private void addColumnas() {

        modelo.addColumn("Código");
        modelo.addColumn("Texto");
         modelo.addColumn("Trabajador");
       

    }

    public void rellenarTabla() {

        ArrayList<Aviso> lavisos = ma.listaAvisos();

        for (Aviso aviso : lavisos) {

            Object[] fila = new Object[4];

            fila[0] = aviso.getCodaviso();
            fila[1] = aviso.getTexto();
            fila[2] = aviso.getTrabajador_dni();

            modelo.addRow(fila);
        }
    }

    /**
     * Métode per vaciar la un Jtable con modelo
     *
     */
    public void vaciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }
}
