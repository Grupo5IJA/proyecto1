/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.utils;

import com.gp.vista.VPrincipal;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextField;

/**
 *
 * @author msimm
 */
public class Utilidades {

    /**
     * Formatea una fecha a "dd/MM/yy" 
     * @param fecha Fecha
     * @return String
     */
    public static String formatearFecha(Date fecha) {

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");

        return formatter.format(fecha);

    }
    
    /**
     * Formatea una fecha a "dd/MM/yyyy" 
     * @param fecha fecha
     * @return String
     */
    public static String formatearFecha2(Date fecha) {

        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        return formatter.format(fecha);

    }
    
    /**
     * Formatea un fecha que contien horas a "HH:mm"
     * @param fecha Fecha
     * @return String
     */
    public static String formatearHora(Date fecha) {

        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");

        return formatter.format(fecha);

    }

    /**
     * A partir de un String obtien un double
     * @param num Numero pero de tipo String
     * @return double
     */
    public static double getDouble(String num) {

        try {
            DecimalFormat formatter = new DecimalFormat("###.##");

            Number numero = formatter.parse(num);
            return numero.doubleValue();
        } catch (ParseException ex) {
            Logger.getLogger(Utilidades.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }

    }

    /**
     * Cifra una contraseña con SHA-256
     * @param contraseña Contraseña
     * @return String
     */
    public static String cifrarContraseña(String contraseña) {

        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
            md.update(contraseña.getBytes());
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(VPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        byte byteData[] = md.digest();

        //Convertir a formato hexadecimal
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < byteData.length; i++) {
            sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
        }
        //System.out.println("Hex format : " + sb.toString());
        return sb.toString();
    }

    /**
     * Valida que un campo solo se introduzcan letras
     * @param campo Campo
     */
    public static void validarSoloLetras(JTextField campo) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (Character.isDigit(c)) {
                    e.consume();
                    if (c != 8) { //Si no es BackSpace
                        Toolkit.getDefaultToolkit().beep();
                    }
                }
            }
        });
    }

    /**
     * Valida que un campo solo se introduzcan números
     * @param campo Campo
     */
    public static void validarSoloNumeros(JTextField campo) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                int k = (int) e.getKeyChar();
                if (!Character.isDigit(c) && k != 44) {
                    e.consume();
                    if (c != 8) { //Si no es BackSpace
                        Toolkit.getDefaultToolkit().beep();
                    }
                }
            }
        });
    }

    /**
     * Valida que un campo solo se introduzcan hasta un núemro de caracteres 
     * determinado
     * @param campo Campo
     * @param len Número de caracteres
     */
    public static void limitarCaracteres(JTextField campo, int len) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                int longitud = campo.getText().length();
                if (longitud >= len) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    /**
     * Valida que un campo solo se introduzcan hasta un núemro determinado de decimales
     * @param campo Campo
     * @param len Número de caracteres
     */
    public static void limitarDecimales(JTextField campo, int len) {
        campo.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                String valor = campo.getText();
                int pos = valor.indexOf(44);
                if (pos > 0 && valor.length() == pos + len + 1) {
                    e.consume();
                    Toolkit.getDefaultToolkit().beep();
                }
            }
        });
    }

    /**
     * devuelve la hora contendia en un campo Date 
     * @param fecha Fecha
     * @return String
     */
    public static String getHora(Date fecha) {

        if(fecha == null){
            return "";            
        }
        
        Instant instant = Instant.ofEpochMilli(fecha.getTime());
        LocalTime lt = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalTime();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm");
        
        return lt.format(dtf);

    }
    
    public static LocalTime getLocalTime(Date date) {

        Instant instant = Instant.ofEpochMilli(date.getTime());
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalTime();
             
    }

    /**
     * Devuelve un Date con "01/01/1970 08:00"
     * @return date
     */
    public static Date getDateOchoHoras() {
        
        Date date = null ;
        
        try {
            date = new SimpleDateFormat("HH:mm").parse("08:00");
         } catch (ParseException ex) {
            Logger.getLogger(Utilidades.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return date;
    }
    
    /**
     * Devuelve un Date con "01/01/1970 00:00"
     * @return Date
     */
    public static Date getDateMin() {

        Calendar calendar = Calendar.getInstance();
        calendar.set(1970, 1, 1, 0, 0, 0);
        return calendar.getTime();

    }
    
    public static Date getDateMax() {

        Calendar calendar = Calendar.getInstance();
        calendar.set(3000, 12, 31, 0, 0, 0);
        return calendar.getTime();

    }
    
    public static Date getDateCero() {

        Calendar calendar = Calendar.getInstance();
        calendar.set(1970, 1, 1, 0, 0, 0);
        return calendar.getTime();

    }
    
    public static Date localTimeToDate(LocalTime lt) {
        
        Instant instant = lt.atDate(LocalDate.of(1970, 1, 1)).atZone(ZoneId.systemDefault()).toInstant();
        return Date.from(instant);
    }

}
