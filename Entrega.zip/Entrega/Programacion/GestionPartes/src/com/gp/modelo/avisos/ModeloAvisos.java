/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.avisos;

import com.gp.modelo.Modelo;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author msimm
 */
public class ModeloAvisos extends Modelo {

    public int insertarAviso(String usdestino, String texto) {

        try {

            sql = "INSERT INTO AVISOS "
                    + "VALUES ( seq_avisos.nextval, ?, ?)";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, usdestino);
            pstatement.setString(2, texto);

            // execute insert SQL stetement
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloAvisos.class.getName());
        } finally {
            limpiarDatos(ModeloAvisos.class.getName());
        }

        return 0;
    }

    public int borrarAviso(int codigo) {

        try {

            sql = "DELETE FROM AVISOS WHERE CODIGO_AVISO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloAvisos.class.getName());
        } finally {
            limpiarDatos(ModeloAvisos.class.getName());
        }

        return 0;
    }

    public int modificarAviso(int codigo, String texto, String dnitrabajador) {

        try {

            sql = "UPDATE AVISOS SET TEXTO_AVISO= ?, TRABAJADOR_DNI_TRABAJADOR= ? "
                    + "WHERE CODIGO_AVISO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, texto);
            pstatement.setString(2, dnitrabajador);
            pstatement.setInt(3, codigo);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloAvisos.class.getName());
        } finally {
            limpiarDatos(ModeloAvisos.class.getName());
        }

        return 0;

    }

    public ArrayList<Aviso> listaAvisos() {

        ArrayList<Aviso> lavisos = new ArrayList<>();

        try {

            sql = "SELECT CODIGO_AVISO, TEXTO_AVISO, TRABAJADOR_DNI_TRABAJADOR FROM AVISOS";
            pstatement = conexion.prepareStatement(sql);

            rs = pstatement.executeQuery();

            while (rs.next()) {

                Aviso aviso = new Aviso();

                aviso.setCodaviso(rs.getInt("CODIGO_AVISO"));
                aviso.setTexto(rs.getString("TEXTO_AVISO"));
                aviso.setTrabajador_dni(rs.getString("TRABAJADOR_DNI_TRABAJADOR"));

                lavisos.add(aviso);
            }

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloAvisos.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloAvisos.class.getName());
        }

        return lavisos;
    }

    public Aviso datosAviso(int codigo) {

        Aviso aviso = null;

        try {

            sql = "SELECT CODIGO_AVISO, TEXTO_AVISO,TRABAJADOR_DNI_TRABAJADOR FROM AVISOS "
                    + "WHERE CODIGO_AVISO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);

            rs = pstatement.executeQuery();

            if (rs.next()) {

                aviso = new Aviso();

                aviso.setCodaviso(codigo);

                aviso.setTexto(rs.getString("TEXTO_AVISO"));
                aviso.setTrabajador_dni(rs.getString("TRABAJADOR_DNI_TRABAJADOR"));
            }

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloAvisos.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloAvisos.class.getName());
        }

        return aviso;
    }

    public Aviso datosAvisoUsuarioDestino(String usdestino) {

        Aviso aviso = null;

        try {

            sql = "SELECT CODIGO_AVISO, TEXTO_AVISO, TRABAJADOR_DNI_TRABAJADOR FROM AVISOS "
                    + "WHERE TRABAJADOR_DNI_TRABAJADOR = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, usdestino);

            rs = pstatement.executeQuery();

            if(rs.next()){
             
                aviso = new Aviso();

                aviso.setCodaviso(rs.getInt("CODIGO_AVISO"));
                aviso.setTexto(rs.getString("TEXTO_AVISO"));
                aviso.setTrabajador_dni(rs.getString("TRABAJADOR_DNI_TRABAJADOR"));   
            }


        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloAvisos.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloAvisos.class.getName());
        }

        return aviso;
    }

}
