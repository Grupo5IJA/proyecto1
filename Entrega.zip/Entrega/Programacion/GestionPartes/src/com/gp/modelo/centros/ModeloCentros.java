/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.centros;

import com.gp.modelo.Modelo;
import java.sql.SQLException;
//import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

/**
 *
 * @author msimm
 */
public class ModeloCentros extends Modelo {

    public int insertarCentro(int codigo, String provincia, String nombre, int numero, String ciudad, String calle, int codigo_postal, String telefono) {

        try {

            sql = "INSERT INTO CENTRO_TRABAJO "
                    + "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);
            pstatement.setString(2, nombre);
            pstatement.setString(3, calle);
            pstatement.setInt(4, numero);
            pstatement.setInt(5, codigo_postal);
            pstatement.setString(6, ciudad);
            pstatement.setString(7, provincia);
            pstatement.setString(8, telefono);

            // execute insert SQL stetement
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloCentros.class.getName());
        } finally {
            limpiarDatos(ModeloCentros.class.getName());
        }

        return 0;
    }

    public int borrarCentro(int codigo) {

        try {

            sql = "DELETE FROM CENTRO_TRABAJO WHERE COD_CENTRO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloCentros.class.getName());
        } finally {
            limpiarDatos(ModeloCentros.class.getName());
        }

        return 0;
    }

    public int modificarCentro(int codigo, String provincia, String nombre, int numero, String ciudad, String calle, int codigo_postal, String telefono) {

        try {

            sql = "UPDATE CENTRO_TRABAJO SET PROVINCIA_CENTRO= ?, NOMBRE_CENTRO= ?, NUMERO_CENTRO= ?, "
                    + "CIUDAD_CENTRO= ?, CALLE_CENTRO= ?, CODIGO_POSTAL_CENTRO= ?, TELEFONO_CENTRO= ? "
                    + "WHERE COD_CENTRO = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setString(1, provincia);
            pstatement.setString(2, nombre);
            pstatement.setInt(3, numero);
            pstatement.setString(4, ciudad);
            pstatement.setString(5, calle);
            pstatement.setInt(6, codigo_postal);
            pstatement.setString(7, telefono);
            pstatement.setInt(8, codigo);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloCentros.class.getName());
        } finally {
            limpiarDatos(ModeloCentros.class.getName());
        }

        return 0;

    }

    public ArrayList<Centro> listaCentros() {

        ArrayList<Centro> lcentros = new ArrayList<>();

        try {

            cstatement = conexion.prepareCall("{call read_centros.buscar_todos_centros (?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            cstatement.registerOutParameter(1, OracleTypes.INTEGER);
            cstatement.registerOutParameter(2, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(3, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(4, OracleTypes.INTEGER);
            cstatement.registerOutParameter(5, OracleTypes.INTEGER);
            cstatement.registerOutParameter(6, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(7, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(8, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(9, OracleTypes.CURSOR); //REF CURSOR

            cstatement.execute();
            rs = ((OracleCallableStatement) cstatement).getCursor(9);

            while (rs.next()) {

                Centro centro = new Centro();

                centro.setCodigo(rs.getInt("COD_CENTRO"));
                centro.setNombre(rs.getString("NOMBRE_CENTRO"));
                centro.setCalle(rs.getString("CALLE_CENTRO"));
                centro.setNumero(rs.getInt("NUMERO_CENTRO"));
                centro.setCodigo_postal(rs.getInt("CODIGO_POSTAL_CENTRO"));
                centro.setCiudad(rs.getString("CIUDAD_CENTRO"));
                centro.setProvincia(rs.getString("PROVINCIA_CENTRO"));
                centro.setTelefono(rs.getString("TELEFONO_CENTRO"));

                lcentros.add(centro);
            }

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloCentros.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloCentros.class.getName());
        }

        return lcentros;
    }

    public Centro datosCentro(int codigo) {

        Centro centro = null;

        try {

            cstatement = conexion.prepareCall("{call read_centros.buscar_centro (?, ?, ?, ?, ?, ?, ?, ?)}");
            cstatement.setInt(1, codigo);
            cstatement.registerOutParameter(2, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(3, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(4, OracleTypes.INTEGER);
            cstatement.registerOutParameter(5, OracleTypes.INTEGER);
            cstatement.registerOutParameter(6, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(7, OracleTypes.VARCHAR);
            cstatement.registerOutParameter(8, OracleTypes.VARCHAR);

            cstatement.executeQuery();

            centro = new Centro();

            centro.setCodigo(codigo);
            centro.setNombre(cstatement.getString(2));
            centro.setCalle(cstatement.getString(3));
            centro.setNumero(cstatement.getInt(4));
            centro.setCodigo_postal(cstatement.getInt(5));
            centro.setCiudad(cstatement.getString(6));
            centro.setProvincia(cstatement.getString(7));
            centro.setTelefono(cstatement.getString(8));

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloCentros.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloCentros.class.getName());
        }

        return centro;
    }
}
