/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.partes;


import com.gp.modelo.ConexionDB;
import com.gp.utils.Utilidades;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author msimm
 */
public class PartesTM {
/**
 *
 * @author msimm
 */
    Connection conexion;
    DefaultTableModel modelo;
    ModeloPartes mp;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public PartesTM(ModeloPartes mp) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.mp = mp;

        addColumnas();

    }

    private void addColumnas() {

        modelo.addColumn("Código");
        modelo.addColumn("Trabajador");
        modelo.addColumn("Fecha parte");
        modelo.addColumn("Km inicio");
        modelo.addColumn("Km fin");
        modelo.addColumn("Total horas");
        modelo.addColumn("G. gasolina");
        modelo.addColumn("G. autopista");
        modelo.addColumn("G dietas");
        modelo.addColumn("Otros gastos");
        modelo.addColumn("Incidencias");
        modelo.addColumn("Estado");
        modelo.addColumn("Exceso horas");
        
    }

    public void rellenarTablaPartes(String dni, Date fecdesde, Date fechasta) {

        ArrayList<Parte> lpaPartes = mp.listaPartes(dni, fecdesde, fechasta);

        for (Parte parte : lpaPartes) {

            Object[] fila = new Object[13];

            fila[0] = parte.getCodigo();
            fila[1] = parte.getTrabajador_dni();
            fila[2] = parte.getFecha_parte();
            fila[3] = parte.getKm_inicio();
            fila[4] = parte.getKm_fin();
            fila[5] = Utilidades.getHora(parte.getTotal_horas());
            fila[6] = parte.getGastos_gasolina();
            fila[7] = parte.getGastos_autopista();
            fila[8] = parte.getGastos_dietas();
            fila[9] = parte.getGastos();
            fila[10] = parte.getIncidencias();
            fila[11] = parte.getEstado();
            fila[12] = Utilidades.getHora(parte.getExceso());

            modelo.addRow(fila);
        }
    }

    /**
     * Métode per vaciar la un Jtable con modelo
     *
     */
    public void vaciarTabla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }
    
}
