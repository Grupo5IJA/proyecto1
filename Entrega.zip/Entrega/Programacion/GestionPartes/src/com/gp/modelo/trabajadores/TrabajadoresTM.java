/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.trabajadores;

import com.gp.modelo.ConexionDB;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author 7fprog01
 */
public class TrabajadoresTM {

    Connection conexion;
    DefaultTableModel modelo;
    ModeloTrabajadores mt;

    public DefaultTableModel getModelo() {
        return modelo;
    }

    public TrabajadoresTM(ModeloTrabajadores mt) {

        this.modelo = new DefaultTableModel();

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();

        this.mt = mt;

        addColumnas();
    }

    private void addColumnas() {

        modelo.addColumn("DNI");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido1");
        modelo.addColumn("Apellido2");
        modelo.addColumn("Calle");
        modelo.addColumn("Portal");
        modelo.addColumn("Piso");
        modelo.addColumn("Mano");
        modelo.addColumn("Telefono Personal");
        modelo.addColumn("Telefono Empresa");
        modelo.addColumn("Salario");
        modelo.addColumn("Fecha Nacimiento");
        modelo.addColumn("Usuario");
        modelo.addColumn("Contraseña");

    }

    public void rellenarTabla() {
        
        ArrayList<Trabajador> ltrabajadores = mt.listaTrabajadores();
              
        for (Trabajador trabajador : ltrabajadores) {

            Object[] fila = new Object[14];
            
            fila[0] = trabajador.getDni();
            fila[1] = trabajador.getNombre();
            fila[2] = trabajador.getApe1();
            fila[3] = trabajador.getApe2();
            fila[4] = trabajador.getCalle();
            fila[5] = trabajador.getPortal();
            fila[6] = trabajador.getPiso();
            fila[7] = trabajador.getMano();
            fila[8] = trabajador.getTelfperson();
            fila[9] = trabajador.getTelfempres();
            fila[10] = trabajador.getSalario();
            fila[11] = trabajador.getFechanac();
            fila[12] = trabajador.getUsuario();
            fila[13] = trabajador.getContra();

            modelo.addRow(fila);

        }
    }

    public void vaciarTabla() {

        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }
}
