/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase padre de todas las clases modelo
 * 
 * Contiene todo lo necesario para acceder a la base de datos
 * 
 * @author msimm
 */
public class Modelo {

    protected final Connection conexion;
    protected PreparedStatement pstatement;
    protected CallableStatement cstatement;
    protected String sql;
    protected ResultSet rs;

    protected Modelo() {

        ConexionDB cdb = ConexionDB.getInstance();
        this.conexion = cdb.getConexion();
        this.pstatement = null;
        this.cstatement = null;
        this.sql = null;
        this.rs = null;

    }

    /**
     * Limpia los datos utilizados para realizar los CRUD de base de datos
     * @param nomclase Nombre de clase
     */
    protected void limpiarDatos(String nomclase) {

        try {
            if (pstatement != null) {
                pstatement.close();
                pstatement = null;
            }
            if (cstatement != null) {
                cstatement.close();
                cstatement = null;
            }
            if (rs != null) {
                rs.close();
                rs = null;
            }
            sql = null;

        } catch (Exception ex) {
            Logger.getLogger(nomclase).log(Level.SEVERE, null, ex);
        }

    }
    
    protected int tratarSQLException(SQLException ex, String nomclase) {

        int coderr = ex.getErrorCode();
        String msgerr = ex.getMessage();

        Logger.getLogger(nomclase).log(Level.SEVERE, null, ex);

        switch (coderr) {
            case 1:
                if (msgerr.contains("_PK")) {
                    //Clave primaria duplicada
                    return -1;
                } else {
                    //Clave única duplicada
                    return -2;
                }
            case 2290: 
                 if (msgerr.contains("VIAJE_HORAS_CK")) {
                    //Hora inicio > hora fin
                    return -3;
                } else if (msgerr.contains("PARTE_KM_CK")){
                    //Km inicio > Km fin
                    return -4;
                } else if (msgerr.contains("PRACTICA.PARTE_TRAB_FECHA_UN")){
                    //Trabajador con más de un parte con la misma fecha
                    return -5;
                }   
             default:
                //Error de base de datos
                return -9;
        }

    }

}
