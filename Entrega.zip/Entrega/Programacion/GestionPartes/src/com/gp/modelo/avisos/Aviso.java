/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.avisos;

/**
 *
 * @author msimm
 */
public class Aviso {
    
    private int codaviso;
    private String texto;
    private String trabajador_dni;

    public int getCodaviso() {
        return codaviso;
    }

    public void setCodaviso(int codaviso) {
        this.codaviso = codaviso;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getTrabajador_dni() {
        return trabajador_dni;
    }

    public void setTrabajador_dni(String trabajador_dni) {
        this.trabajador_dni = trabajador_dni;
    }
    
    
    
}
