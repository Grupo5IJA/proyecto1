/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gp.modelo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;


 /**
     * Clase para establecer la conexión con la base de datos.
     * 
     * Utiliza el patrón Singleton (solo puede existir una instancia de esta clase)
     * 
     */
public class ConexionDB {
    
    private static ConexionDB instance = null;
    
    private String url = null;
    private String user = null;
    private String pwd = null;    
  
    private Connection conexion;
  
    /**
     * Devuleve la conexión
     * @return Connection
     */
    public Connection getConexion() {
        return conexion;
    }

    /**
     * Establece la conexión con la base de datos
     * Utiliza el patrón Singleton (solo puede existir una instancia de esta clase)
     * 
     * @return
     */
    private void setConexion() {
    
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            this.conexion = DriverManager.getConnection(url, user, pwd);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }
    
    /**
     * Devuelve la única instancia existente de esta clase
     * @return conexionDB
     */
    public static ConexionDB getInstance() {
        
        if(instance == null){
            instance = new ConexionDB();
            instance.leerProperties();
            instance.setConexion();
        }
        return instance;
        
    }
    
    /**
     * Cierra la conexión con la base de datos
     */
    public void cerrarConexion(){
        try {
            this.conexion.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
          
    @SuppressWarnings("ConvertToTryWithResources")
    private void leerProperties() {

        try {

            Properties prop = new Properties();
            InputStream in = getClass().getResourceAsStream("conexion.properties");
            prop.load(in);
            
            this.url = prop.getProperty("url");
            this.user = prop.getProperty("username");
            this.pwd = prop.getProperty("password");            
            in.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ConexionDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
 }


