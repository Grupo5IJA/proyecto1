/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.viajes;

import com.gp.modelo.Modelo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author msimm
 */
public class ModeloViajes extends Modelo {

    public int insertarViaje(Date horaini, Date horafin, String codalbaran, int codparte) {

        try {

            sql = "INSERT INTO VIAJE "
                    + "VALUES ( SEQ_VIAJE.nextval, ?, ?, ?, ?)";
            pstatement = conexion.prepareStatement(sql);

            //pstatement.setInt(1, codigo);
            pstatement.setDate(1, new java.sql.Date(horaini.getTime()));
            pstatement.setDate(2, new java.sql.Date(horafin.getTime()));
            pstatement.setString(3, codalbaran);
            pstatement.setInt(4, codparte);

            // execute insert SQL stetement
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloViajes.class.getName());
        } finally {
            limpiarDatos(ModeloViajes.class.getName());
        }

        return 0;
    }

    public int borrarViaje(int codigo) {

        try {

            sql = "DELETE FROM VIAJE WHERE CODIGO_VIAJE = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);
            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloViajes.class.getName());
        } finally {
            limpiarDatos(ModeloViajes.class.getName());
        }

        return 0;
    }

    public int modificarViaje(int codigo, Date horaini, Date horafin, String codalbaran, int codparte) {

        try {

            sql = "UPDATE VIAJE SET HORA_INICIO_VIAJE= ?, HORA_FIN_VIAJE= ?, ALBARAN_PARTE= ?, PARTE_CODIGO_PARTE = ? "
                    + "WHERE CODIGO_VIAJE = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setDate(1, new java.sql.Date(horaini.getTime()));
            pstatement.setDate(2, new java.sql.Date(horafin.getTime()));
            pstatement.setString(3, codalbaran);
            pstatement.setInt(4, codparte);
            pstatement.setInt(5, codigo);

            pstatement.executeUpdate();

        } catch (SQLException ex) {
            return tratarSQLException(ex, ModeloViajes.class.getName());
        } finally {
            limpiarDatos(ModeloViajes.class.getName());
        }

        return 0;

    }

    public ArrayList<Viaje> listaViajes() {

        ArrayList<Viaje> lviajes = new ArrayList<>();

        try {

            sql = "SELECT CODIGO_VIAJE, HORA_INICIO_VIAJE, HORA_FIN_VIAJE, ALBARAN_PARTE, PARTE_CODIGO_PARTE FROM VIAJE ORDER BY CODIGO_VIAJE";
            pstatement = conexion.prepareStatement(sql);

            rs = pstatement.executeQuery();

            while (rs.next()) {

                Viaje viaje = new Viaje();

                viaje.setCodigo(rs.getInt("CODIGO_VIAJE"));
                viaje.setHoraini(rs.getDate("HORA_INICIO_VIAJE"));
                viaje.setHorafin(rs.getDate("HORA_FIN_VIAJE"));
                viaje.setCodalbaran(rs.getString("ALBARAN_PARTE"));
                viaje.setCodparte(rs.getInt("PARTE_CODIGO_PARTE"));

                lviajes.add(viaje);
            }
        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloViajes.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloViajes.class.getName());
        }

        return lviajes;
    }

    public ArrayList<Viaje> listaViajesParte(int codparte) {

        ArrayList<Viaje> lviajes = new ArrayList<>();

        try {

            sql = "SELECT CODIGO_VIAJE, HORA_INICIO_VIAJE, HORA_FIN_VIAJE, ALBARAN_PARTE FROM VIAJE "
                    + "WHERE PARTE_CODIGO_PARTE = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codparte);

            rs = pstatement.executeQuery();

            while (rs.next()) {

                Viaje viaje = new Viaje();

                viaje.setCodigo(rs.getInt("CODIGO_VIAJE"));
                viaje.setHoraini(rs.getDate("HORA_INICIO_VIAJE"));
                viaje.setHorafin(rs.getDate("HORA_FIN_VIAJE"));
                viaje.setCodalbaran(rs.getString("ALBARAN_PARTE"));
                viaje.setCodparte(codparte);

                lviajes.add(viaje);
            }
        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloViajes.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloViajes.class.getName());
        }

        return lviajes;
    }

    public Viaje datosViaje(int codigo) {

        Viaje viaje = null;

        try {

            sql = "SELECT HORA_INICIO_VIAJE, HORA_FIN_VIAJE, ALBARAN_PARTE, PARTE_CODIGO_PARTE FROM VIAJE "
                    + "WHERE CODIGO_VIAJE = ?";
            pstatement = conexion.prepareStatement(sql);

            pstatement.setInt(1, codigo);

            rs = pstatement.executeQuery();

            if (rs.next()) {

                viaje = new Viaje();

                viaje.setCodigo(codigo);
                viaje.setHoraini(rs.getDate("HORA_INICIO_VIAJE"));
                viaje.setHorafin(rs.getDate("HORA_FIN_VIAJE"));
                viaje.setCodalbaran(rs.getString("ALBARAN_PARTE"));
                viaje.setCodparte(rs.getInt("PARTE_CODIGO_PARTE"));
            }

        } catch (SQLException ex) {
            tratarSQLException(ex, ModeloViajes.class.getName());
            return null;
        } finally {
            limpiarDatos(ModeloViajes.class.getName());
        }

        return viaje;
    }

}
