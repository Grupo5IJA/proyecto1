/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gp.modelo.partes;

import java.util.Date;

/**
 *
 * @author msimm
 */
public class Parte {
    
    private int codigo;
    private Date fecha_parte;
    private int km_inicio;
    private int km_fin;
    private Date total_horas;
    private double gastos_gasolina;
    private double gastos_autopista;
    private double gastos_dietas;
    private double gastos;
    private String incidencias;
    private char estado; 
    private String trabajador_dni;
    private String vehiculo_matricula;
    private Date exceso;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int coidgo) {
        this.codigo = coidgo;
    }

    public Date getFecha_parte() {
        return fecha_parte;
    }

    public void setFecha_parte(Date fecha_parte) {
        this.fecha_parte = fecha_parte;
    }

    public int getKm_inicio() {
        return km_inicio;
    }

    public void setKm_inicio(int km_inicio) {
        this.km_inicio = km_inicio;
    }

    public int getKm_fin() {
        return km_fin;
    }

    public void setKm_fin(int km_fin) {
        this.km_fin = km_fin;
    }

    public Date getTotal_horas() {
        return total_horas;
    }

    public void setTotal_horas(Date total_horas) {
        this.total_horas = total_horas;
    }

    public double getGastos_gasolina() {
        return gastos_gasolina;
    }

    public void setGastos_gasolina(double gastos_gasolina) {
        this.gastos_gasolina = gastos_gasolina;
    }

    public double getGastos_autopista() {
        return gastos_autopista;
    }

    public void setGastos_autopista(double gastos_autopista) {
        this.gastos_autopista = gastos_autopista;
    }

    public double getGastos_dietas() {
        return gastos_dietas;
    }

    public void setGastos_dietas(double gastos_dietas) {
        this.gastos_dietas = gastos_dietas;
    }

    public double getGastos() {
        return gastos;
    }

    public void setGastos(double gastos) {
        this.gastos = gastos;
    }

    public String getIncidencias() {
        return incidencias;
    }

    public void setIncidencias(String incidencias) {
        this.incidencias = incidencias;
    }

    public char getEstado() {
        return estado;
    }

    public void setEstado(char estado) {
        this.estado = estado;
    }

    public String getTrabajador_dni() {
        return trabajador_dni;
    }

    public void setTrabajador_dni(String trabajador_dni) {
        this.trabajador_dni = trabajador_dni;
    }

    public String getVehiculo_matricula() {
        return vehiculo_matricula;
    }

    public void setVehiculo_matricula(String vehiculo_matricula) {
        this.vehiculo_matricula = vehiculo_matricula;
    }

    public Date getExceso() {
        return exceso;
    }

    public void setExceso(Date exceso) {
        this.exceso = exceso;
    }
}
